/**
 * AKSHAY AI TOOLS - GLOBAL CONFIGURATION
 * 
 * Edit this file to update the brand name, contact info, logos, and API keys 
 * across the entire website from one single place.
 */

const CONFIG = {
    // Brand & Identity
    appName: "Akshay AI Tools",
    logoPath: "favicon.png",
    
    // Contact Information
    contactEmail: "bhorakshay146@gmail.com",
    contactPhone: "+91 7249558414",

    // API Keys & Secrets
    apiKeys: {
        gemini: "YOUR_GEMINI_API_KEY_HERE",
        openai: "YOUR_OPENAI_API_KEY_HERE",
        insforgeAnon: "YOUR_INSFORGE_ANON_KEY_HERE"
    },

    // AI Tool Routing Configuration
    // Assign specific models and API keys to different tools
    tools: {
        chat: { provider: "gemini", model: "gemini-1.5-pro-latest" },
        code: { provider: "openai", model: "gpt-4o" },
        text: { provider: "gemini", model: "gemini-1.5-flash" },
        image: { provider: "openai", model: "dall-e-3" },
        reels: { provider: "gemini", model: "gemini-1.5-flash" },
        default: { provider: "gemini", model: "gemini-1.5-flash" }
    },

    // Optional Links
    links: {
        twitter: "https://twitter.com/",
        github: "https://github.com/",
    }
};

// Auto-apply configuration to the DOM when the page loads
document.addEventListener("DOMContentLoaded", () => {
    // Helper function to safely replace text within specific tags
    const replaceTextInElements = (selector, oldText, newText) => {
        document.querySelectorAll(selector).forEach(el => {
            if (el.innerHTML.includes(oldText)) {
                // If the element has children, only replace text nodes to avoid killing HTML
                if (el.children.length === 0) {
                    el.textContent = el.textContent.replace(new RegExp(oldText, 'g'), newText);
                } else {
                    el.childNodes.forEach(node => {
                        if (node.nodeType === 3 && node.nodeValue.includes(oldText)) {
                            node.nodeValue = node.nodeValue.replace(new RegExp(oldText, 'g'), newText);
                        }
                    });
                }
            }
        });
    };

    // 1. Update Brand Name where it usually appears (spans, headers, titles)
    replaceTextInElements('span, h1, h2, p, title', 'Akshay AI Tools', CONFIG.appName);

    // 2. Update Contact Emails
    document.querySelectorAll('a[href^="mailto:"]').forEach(a => {
        if (a.href.includes('bhorakshay146@gmail.com')) {
            a.href = `mailto:${CONFIG.contactEmail}`;
            a.innerHTML = a.innerHTML.replace('bhorakshay146@gmail.com', CONFIG.contactEmail);
        }
    });

    // 3. Update Contact Phones
    document.querySelectorAll('a[href^="tel:"]').forEach(a => {
        if (a.href.includes('+917249558414') || a.href.includes('+91 7249558414')) {
            const cleanPhone = CONFIG.contactPhone.replace(/\s+/g, '');
            a.href = `tel:${cleanPhone}`;
            a.innerHTML = a.innerHTML.replace('+91 7249558414', CONFIG.contactPhone);
        }
    });

    // 4. Update Logos
    document.querySelectorAll('img').forEach(img => {
        if (img.src.includes('favicon.png')) {
            img.src = CONFIG.logoPath;
        }
    });
});
