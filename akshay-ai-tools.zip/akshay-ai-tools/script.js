/* ===========================
   AKSHAY AI TOOLS - SCRIPT.JS
   REAL AI POWERED + INSFORGE AUTH
   + SECURITY HARDENED
   =========================== */

// ── SECURE: API key is now server-side via Insforge edge function ──
const AI_PROXY_URL = 'https://ky872wnv.ap-southeast.insforge.app/functions/ai-proxy';

// ═══════════════════════════
//  SECURITY UTILITIES
// ═══════════════════════════

// ── XSS Sanitizer: Prevent cross-site scripting ──
function sanitizeHTML(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

// ── Rate Limiter: Prevent AI API abuse ──
const RATE_LIMIT = {
  maxCalls: 10,        // max calls per window
  windowMs: 60000,     // 1 minute window
  calls: [],
  check: function() {
    const now = Date.now();
    this.calls = this.calls.filter(t => now - t < this.windowMs);
    if (this.calls.length >= this.maxCalls) {
      return false; // rate limited
    }
    this.calls.push(now);
    return true; // allowed
  }
};

// ── Input Validator ──
function validateInput(input, maxLength = 2000) {
  if (!input || typeof input !== 'string') return '';
  // Trim and limit length
  let clean = input.trim().substring(0, maxLength);
  return clean;
}

// ── Anti-Tamper: Protect auth from console manipulation ──
function verifyAuthIntegrity() {
  try {
    const token = localStorage.getItem('insforge_token');
    const userStr = localStorage.getItem('insforge_user');
    if (token && !userStr) { localStorage.removeItem('insforge_token'); return false; }
    if (!token && userStr) { localStorage.removeItem('insforge_user'); return false; }
    if (token && userStr) {
      const user = JSON.parse(userStr);
      if (!user || !user.id || !user.email) {
        localStorage.removeItem('insforge_token');
        localStorage.removeItem('insforge_user');
        localStorage.removeItem('insforge_csrf');
        return false;
      }
      // Basic JWT structure check (3 parts separated by dots)
      const parts = token.split('.');
      if (parts.length !== 3) {
        localStorage.removeItem('insforge_token');
        localStorage.removeItem('insforge_user');
        localStorage.removeItem('insforge_csrf');
        return false;
      }
    }
    return true;
  } catch (e) {
    localStorage.removeItem('insforge_token');
    localStorage.removeItem('insforge_user');
    localStorage.removeItem('insforge_csrf');
    return false;
  }
}

// ── Typewriter Effect: Smooth text reveal ──
function typewriterEffect(element, text, speed = 10, callback = null) {
  let i = 0;
  element.textContent = '';
  function type() {
    if (i < text.length) {
      element.textContent += text.charAt(i);
      i++;
      setTimeout(type, speed);
    } else if (callback) {
      callback();
    }
  }
  type();
}

// ── Auth State (uses Insforge via insforge.js) ──
const AUTH = {
  isLoggedIn: () => typeof INSFORGE !== 'undefined' ? INSFORGE.auth.isLoggedIn() : false,
  getUser: () => {
    if (typeof INSFORGE === 'undefined') return {};
    const user = INSFORGE.auth.getUser();
    if (!user) return {};
    return {
      name: (user.profile && user.profile.name) || (user.email && user.email.split('@')[0]) || 'User',
      email: user.email || '',
      id: user.id || ''
    };
  },
  logout: async () => {
    if (typeof INSFORGE !== 'undefined') await INSFORGE.auth.signOut();
  }
};

// ── History (local + Insforge DB) ──
const HISTORY = {
  get: () => JSON.parse(localStorage.getItem('aat_history') || '[]'),
  add: async (item) => {
    // Local cache
    const h = HISTORY.get();
    h.unshift({ ...item, time: new Date().toISOString(), id: Date.now() });
    if (h.length > 50) h.pop();
    localStorage.setItem('aat_history', JSON.stringify(h));

    // Save to Insforge DB
    if (typeof INSFORGE !== 'undefined' && INSFORGE.auth.isLoggedIn()) {
      try {
        const user = INSFORGE.auth.getUser();
        await INSFORGE.db.insert('user_activity', {
          user_id: user.id,
          tool: item.tool,
          type: item.type,
          prompt: (item.prompt ? item.prompt.substring(0, 500) : '')
        });
      } catch (e) {
        console.warn('Failed to save activity to Insforge:', e.message);
      }
    }
  }
};

// ── Theme ──
const THEME = {
  get: () => localStorage.getItem('aat_theme') || 'dark',
  set: (t) => { localStorage.setItem('aat_theme', t); document.documentElement.setAttribute('data-theme', t); },
  toggle: () => { const t = THEME.get() === 'dark' ? 'light' : 'dark'; THEME.set(t); updateThemeBtn(); }
};

function updateThemeBtn() {
  const btn = document.getElementById('theme-toggle');
  if (btn) btn.textContent = THEME.get() === 'dark' ? '☀️' : '🌙';
}

// ── Language ──
const LANG = {
  get: () => localStorage.getItem('aat_lang') || 'en',
  set: (l) => localStorage.setItem('aat_lang', l)
};

// ── Toast ──
function showToast(message, type = 'success', icon = '✓') {
  let toast = document.getElementById('toast');
  if (!toast) { toast = document.createElement('div'); toast.id = 'toast'; toast.className = 'toast'; document.body.appendChild(toast); }
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span class="toast-icon">${icon}</span><span>${message}</span>`;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3200);
}

// ── AI API Call (Direct REST APIs for Gemini & OpenAI based on Tool Config) ──
async function callAI(prompt, systemPrompt = '') {
  // Rate limit check
  if (!RATE_LIMIT.check()) {
    throw new Error('Too many requests. Please wait a moment before trying again.');
  }

  // Sanitize inputs
  const cleanPrompt = validateInput(prompt, 3000);
  const cleanSystem = validateInput(systemPrompt, 2000);
  if (!cleanPrompt) throw new Error('Please provide a valid prompt.');

  try {
    // 1. Determine which tool is calling this function via body dataset
    const pageId = document.body.dataset.page || 'default';
    
    // 2. Lookup the provider and model from our global config.js
    const toolConfig = (typeof CONFIG !== 'undefined' && CONFIG.tools && CONFIG.tools[pageId]) 
      ? CONFIG.tools[pageId] 
      : { provider: 'gemini', model: 'gemini-1.5-flash' };

    const provider = toolConfig.provider;
    let finalOutput = "";

    // ──────────────────────────────────────────
    // GOOGLE GEMINI (Direct REST API)
    // ──────────────────────────────────────────
    if (provider === 'gemini') {
      const apiKey = typeof CONFIG !== 'undefined' ? CONFIG.apiKeys.gemini : '';
      if (!apiKey || apiKey === 'YOUR_GEMINI_API_KEY_HERE') throw new Error("Gemini API Key is missing in config.js");

      // Construct Gemini prompt structure
      const contents = [];
      if (cleanSystem) {
        contents.push({ role: 'user', parts: [{ text: `SYSTEM DIRECTIVE: ${cleanSystem}\n\nUSER PROMPT: ${cleanPrompt}` }] });
      } else {
        contents.push({ role: 'user', parts: [{ text: cleanPrompt }] });
      }

      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${toolConfig.model}:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contents: contents })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error?.message || `Gemini API Error ${res.status}`);
      }

      const data = await res.json();
      finalOutput = data.candidates?.[0]?.content?.parts?.[0]?.text || "No response generated.";
    } 
    
    // ──────────────────────────────────────────
    // OPENAI (Direct REST API)
    // ──────────────────────────────────────────
    else if (provider === 'openai') {
      const apiKey = typeof CONFIG !== 'undefined' ? CONFIG.apiKeys.openai : '';
      if (!apiKey || apiKey === 'YOUR_OPENAI_API_KEY_HERE') throw new Error("OpenAI API Key is missing in config.js");

      const messages = [];
      if (cleanSystem) messages.push({ role: "system", content: cleanSystem });
      messages.push({ role: "user", content: cleanPrompt });

      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: toolConfig.model,
          messages: messages
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error?.message || `OpenAI API Error ${res.status}`);
      }

      const data = await res.json();
      finalOutput = data.choices?.[0]?.message?.content || "No response generated.";
    } 
    else {
      throw new Error(`Unsupported AI Provider: ${provider}`);
    }

    // Sanitize AI response before returning
    return sanitizeHTML(finalOutput);

  } catch (err) {
    throw err;
  }
}

// ── Nav ──
function initNav() {
  const hamburger = document.querySelector('.hamburger');
  const navLinks = document.querySelector('.nav-links');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => navLinks.classList.toggle('open'));
    navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));
  }

  // Inject profile avatar into navbar if not already present
  if (!document.querySelector('.nav-avatar') && typeof AUTH !== 'undefined' && AUTH.isLoggedIn()) {
    const nav = document.querySelector('nav') || document.querySelector('.navbar');
    if (nav) {
      const avatarLink = document.createElement('a');
      avatarLink.href = 'dashboard.html';
      avatarLink.className = 'nav-avatar-link';
      avatarLink.title = 'Akshay';
      avatarLink.innerHTML = '<img src="akshay-profile.jpg" alt="Akshay" class="nav-avatar">';
      const navCta = nav.querySelector('.nav-cta');
      const navInner = nav.querySelector('.nav-inner');
      if (navCta) navCta.appendChild(avatarLink);
      else if (navInner) navInner.appendChild(avatarLink);
      else nav.appendChild(avatarLink);
    }
  }

  // Inject global contact info to footers
  const footerBottoms = document.querySelectorAll('.footer-bottom');
  footerBottoms.forEach(fb => {
    if (!fb.querySelector('.global-contact-info')) {
      const contactDiv = document.createElement('div');
      contactDiv.className = 'global-contact-info';
      contactDiv.style.display = 'flex';
      contactDiv.style.gap = '20px';
      contactDiv.style.alignItems = 'center';
      contactDiv.style.justifyContent = 'center';
      contactDiv.style.flexWrap = 'wrap';
      contactDiv.style.marginTop = '12px';
      contactDiv.style.width = '100%';
      contactDiv.innerHTML = `
        <span style="color:var(--text-secondary);font-size:0.85rem;font-weight:600">Feedback & Contact:</span>
        <a href="mailto:bhorakshay146@gmail.com" style="color:var(--accent-cyan);text-decoration:none;font-size:0.85rem;display:flex;align-items:center;gap:6px">📧 bhorakshay146@gmail.com</a>
        <a href="tel:+917249558414" style="color:var(--accent-cyan);text-decoration:none;font-size:0.85rem;display:flex;align-items:center;gap:6px">📞 +91 7249558414</a>
      `;
      fb.style.flexWrap = 'wrap';
      fb.appendChild(contactDiv);
    }
  });

  THEME.set(THEME.get());
  updateThemeBtn();
  const themeBtn = document.getElementById('theme-toggle');
  if (themeBtn) themeBtn.addEventListener('click', THEME.toggle);
  updateNavAuth();
}

function updateNavAuth() {
  const loginLink = document.getElementById('nav-login');
  const signupLink = document.getElementById('nav-signup');
  const dashLink = document.getElementById('nav-dashboard');
  const logoutLink = document.getElementById('nav-logout');
  const isLoggedIn = AUTH.isLoggedIn();

  if (isLoggedIn) {
    if (loginLink) loginLink.style.display = 'none';
    if (signupLink) signupLink.style.display = 'none';
    if (dashLink) dashLink.style.display = '';
    if (logoutLink) logoutLink.style.display = '';
  } else {
    if (loginLink) loginLink.style.display = '';
    if (signupLink) signupLink.style.display = '';
    if (dashLink) dashLink.style.display = 'none';
    if (logoutLink) logoutLink.style.display = 'none';
  }
}

async function handleLogout() {
  await AUTH.logout();
  showToast('Logged out successfully', 'success', '👋');
  setTimeout(() => window.location.href = 'index.html', 900);
}

// ── Scroll Reveals ──
function initReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(el => { if (el.isIntersecting) el.target.classList.add('visible'); });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}

// ── Login (Insforge) ──
function initLogin() {
  const form = document.getElementById('loginForm');
  if (!form) return;

  // If already logged in, redirect
  if (AUTH.isLoggedIn()) { window.location.href = 'dashboard.html'; return; }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFieldErrors();

    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPass').value;

    // Validate
    let valid = true;
    if (!email || !email.includes('@')) {
      showFieldError('loginEmailErr', 'Enter a valid email address');
      valid = false;
    }
    if (password.length < 6) {
      showFieldError('loginPassErr', 'Password must be at least 6 characters');
      valid = false;
    }
    if (!valid) return;

    const btn = document.getElementById('loginBtn');
    btn.classList.add('loading');
    btn.disabled = true;

    try {
      await INSFORGE.auth.signIn({ email, password });
      showToast('Welcome back! 🎉', 'success', '✓');
      setTimeout(() => window.location.href = 'dashboard.html', 900);
    } catch (err) {
      showAlert('loginAlert', err.message, 'error');
      btn.classList.remove('loading');
      btn.disabled = false;
    }
  });
}

// ── Signup (Insforge + Email Verification) ──
let signupEmail = '';

function initSignup() {
  const form = document.getElementById('signupForm');
  if (!form) return;

  if (AUTH.isLoggedIn()) { window.location.href = 'dashboard.html'; return; }

  // Signup form submit
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFieldErrors();

    const name = document.getElementById('signupName').value.trim();
    const email = document.getElementById('signupEmail').value.trim();
    const password = document.getElementById('signupPass').value;
    const confirm = document.getElementById('signupConfirm').value;

    let valid = true;
    if (name.length < 2) { showFieldError('signupNameErr', 'Name is too short'); valid = false; }
    if (!email || !email.includes('@')) { showFieldError('signupEmailErr', 'Enter a valid email'); valid = false; }
    if (password.length < 6) { showFieldError('signupPassErr', 'Minimum 6 characters'); valid = false; }
    if (password !== confirm) { showFieldError('signupConfirmErr', 'Passwords do not match'); valid = false; }
    if (!valid) return;

    const btn = document.getElementById('signupBtn');
    btn.classList.add('loading');
    btn.disabled = true;

    try {
      const result = await INSFORGE.auth.signUp({ email, password, name });
      if (result.requireVerification) {
        signupEmail = email;
        document.getElementById('signupStep').classList.remove('active');
        document.getElementById('verifyStep').classList.add('active');
        document.getElementById('verifyEmailDisplay').textContent = email;
        // Focus first OTP input
        document.querySelector('.otp-input')?.focus();
      } else {
        showToast('Account created! 🚀', 'success', '✓');
        setTimeout(() => window.location.href = 'dashboard.html', 900);
      }
    } catch (err) {
      showAlert('signupAlert', err.message, 'error');
      btn.classList.remove('loading');
      btn.disabled = false;
    }
  });

  // OTP input auto-advance
  const otpInputs = document.querySelectorAll('.otp-input');
  otpInputs.forEach((inp, i) => {
    inp.addEventListener('input', (e) => {
      const val = e.target.value.replace(/[^0-9]/g, '');
      e.target.value = val;
      if (val && i < otpInputs.length - 1) {
        otpInputs[i + 1].focus();
      }
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && !e.target.value && i > 0) {
        otpInputs[i - 1].focus();
      }
    });
    // Paste support
    inp.addEventListener('paste', (e) => {
      e.preventDefault();
      const text = (e.clipboardData || window.clipboardData).getData('text').replace(/[^0-9]/g, '');
      for (let j = 0; j < Math.min(text.length, 6); j++) {
        otpInputs[j].value = text[j];
      }
      otpInputs[Math.min(text.length, 5)].focus();
    });
  });

  // Verify button
  const verifyBtn = document.getElementById('verifyBtn');
  if (verifyBtn) {
    verifyBtn.addEventListener('click', async () => {
      const otp = Array.from(otpInputs).map(i => i.value).join('');
      if (otp.length !== 6) {
        showAlert('verifyAlert', 'Please enter the complete 6-digit code', 'error');
        return;
      }

      verifyBtn.classList.add('loading');
      verifyBtn.disabled = true;

      try {
        await INSFORGE.auth.verifyEmail({ email: signupEmail, otp });
        showToast('Email verified! Welcome! 🎉', 'success', '✓');
        setTimeout(() => window.location.href = 'dashboard.html', 900);
      } catch (err) {
        showAlert('verifyAlert', err.message, 'error');
        verifyBtn.classList.remove('loading');
        verifyBtn.disabled = false;
      }
    });
  }

  // Resend button
  const resendBtn = document.getElementById('resendBtn');
  if (resendBtn) {
    resendBtn.addEventListener('click', async () => {
      resendBtn.disabled = true;
      resendBtn.textContent = 'Sending...';
      try {
        await INSFORGE.auth.resendVerification({ email: signupEmail });
        showAlert('verifyAlert', 'New code sent! Check your email.', 'success');
        resendBtn.textContent = 'Sent ✓';
        setTimeout(() => { resendBtn.textContent = 'Resend Code'; resendBtn.disabled = false; }, 30000);
      } catch (err) {
        showAlert('verifyAlert', err.message, 'error');
        resendBtn.textContent = 'Resend Code';
        resendBtn.disabled = false;
      }
    });
  }
}

// ── Helper: Field errors ──
function showFieldError(id, msg) {
  const el = document.getElementById(id);
  if (el) el.textContent = msg;
}

function clearFieldErrors() {
  document.querySelectorAll('.field-error').forEach(el => el.textContent = '');
  document.querySelectorAll('.form-error').forEach(el => { el.textContent = ''; el.classList.remove('show'); });
}

function showAlert(id, msg, type = 'error') {
  const el = document.getElementById(id);
  if (el) {
    el.textContent = msg;
    el.className = `alert-box ${type} show`;
  }
}

// Old helpers for backward compatibility
function showError(id, msg) { const el = document.getElementById(id); if (el) { el.textContent = msg; el.classList.add('show'); } }
function clearErrors() { clearFieldErrors(); }

// ── Dashboard ──
function initDashboard() {
  if (!AUTH.isLoggedIn()) { window.location.href = 'login.html'; return; }
  const user = AUTH.getUser();
  const nameEl = document.getElementById('user-name');
  const greetEl = document.getElementById('user-greeting');
  const avatarEl = document.getElementById('user-avatar');
  if (nameEl) nameEl.textContent = user.name || 'User';
  if (greetEl) { const h = new Date().getHours(); greetEl.textContent = h < 12 ? 'Good morning ☀️' : h < 17 ? 'Good afternoon 🌤️' : 'Good evening 🌙'; }
  if (avatarEl) {
    avatarEl.textContent = (user.name || 'U')[0].toUpperCase();
  }
  animateCounters();
  loadRecentHistory();
}

function animateCounters() {
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = parseInt(el.dataset.count);
    let current = 0;
    const step = Math.ceil(target / 50);
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = Math.floor(current) + (el.dataset.suffix || '');
      if (current >= target) clearInterval(timer);
    }, 28);
  });
}

function loadRecentHistory() {
  const container = document.getElementById('activity-list');
  if (!container) return;
  const history = HISTORY.get().slice(0, 5);
  if (!history.length) return;
  const colorMap = { text: 'violet', image: 'cyan', code: 'pink', chat: 'gold' };
  container.innerHTML = history.map(item => `
    <div class="activity-item">
      <div class="activity-dot ${colorMap[item.type] || 'cyan'}"></div>
      <div class="activity-text"><strong>${item.tool}</strong> — ${item.prompt.substring(0, 50)}...</div>
      <div class="activity-time">${timeAgo(item.time)}</div>
    </div>
  `).join('');
}

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr ago`;
  return `${Math.floor(hrs / 24)} day ago`;
}

// ── Voice Input ──
function initVoiceInput(inputId) {
  const btn = document.getElementById('voice-btn');
  if (!btn) return;
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    btn.style.display = 'none'; return;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const recognition = new SR();
  recognition.continuous = false;
  recognition.interimResults = false;

  btn.addEventListener('click', () => {
    const lang = (document.getElementById('lang-select') ? document.getElementById('lang-select').value : 'en-US');
    recognition.lang = lang;
    recognition.start();
    btn.textContent = '🔴';
    btn.style.background = 'rgba(255,45,120,0.2)';
    showToast('Listening... speak now!', 'success', '🎤');
  });

  recognition.onresult = (e) => {
    const transcript = e.results[0][0].transcript;
    const input = document.getElementById(inputId);
    if (input) input.value = transcript;
    btn.textContent = '🎤'; btn.style.background = '';
    showToast('Voice captured!', 'success', '✓');
  };
  recognition.onerror = () => { btn.textContent = '🎤'; btn.style.background = ''; };
  recognition.onend = () => { btn.textContent = '🎤'; btn.style.background = ''; };
}

// ── Real AI Text Generator ──
function initTextGenerator() {
  const btn = document.getElementById('generate-text-btn');
  const output = document.getElementById('text-output');
  const prompt = document.getElementById('text-prompt');
  if (!btn) return;
  initVoiceInput('text-prompt');

  btn.addEventListener('click', async () => {
    const p = prompt.value.trim();
    if (!p) { showToast('Please enter a prompt!', 'error', '⚠'); return; }
    const tone = (document.getElementById('text-tone') ? document.getElementById('text-tone').value : 'professional');
    const type = (document.getElementById('text-type') ? document.getElementById('text-type').value : 'blog');
    const length = (document.getElementById('text-length') ? document.getElementById('text-length').value : 'medium');
    const lang = (document.getElementById('lang-select') ? document.getElementById('lang-select').value : 'en-US');
    const langName = lang.startsWith('mr') ? 'Marathi' : lang.startsWith('hi') ? 'Hindi' : 'English';

    output.innerHTML = `<div class="generating"><div class="gen-dot"></div><div class="gen-dot"></div><div class="gen-dot"></div><span>Generating with akshay-ai-tools…</span></div>`;
    btn.disabled = true; btn.textContent = '⏳ Generating...';

    const systemPrompt = `You are an expert ${type} writer. Write in a ${tone} tone. Length: ${length}. Language: ${langName}. Write only the content, no extra explanation.`;

    try {
      const response = await callAI(p, systemPrompt);
      output.textContent = '';
      typewriterEffect(output, response, 12, () => {
        btn.disabled = false; btn.textContent = '✨ Generate Text';
        HISTORY.add({ type: 'text', tool: 'AI Text Generator', prompt: p });
        showToast('Text generated by akshay-ai-tools! ✨', 'success', '✓');
      });
    } catch (err) {
      output.textContent = '❌ Error: ' + err.message;
      btn.disabled = false; btn.textContent = '✨ Generate Text';
      showToast('API Error!', 'error', '❌');
    }
  });
}

function typewriterEffect(el, text, speed, callback) {
  el.textContent = '';
  let i = 0;
  const timer = setInterval(() => {
    el.textContent += text[i++];
    el.scrollTop = el.scrollHeight;
    if (i >= text.length) { clearInterval(timer); if (callback) callback(); }
  }, speed);
}

// ── Real AI Image Generator ──
function initImageGenerator() {
  const btn = document.getElementById('generate-image-btn');
  const grid = document.getElementById('image-output-grid');
  const prompt = document.getElementById('image-prompt');
  if (!btn) return;
  initVoiceInput('image-prompt');

  btn.addEventListener('click', async () => {
    const p = prompt.value.trim();
    if (!p) { showToast('Please describe the image!', 'error', '⚠'); return; }
    const style = (document.getElementById('image-style') ? document.getElementById('image-style').value : 'realistic');

    btn.textContent = '⏳ Generating...'; btn.disabled = true;
    grid.innerHTML = Array(4).fill(0).map((_, i) => `
      <div class="image-placeholder" id="img-${i}">
        <div class="generating"><div class="gen-dot"></div><div class="gen-dot"></div><div class="gen-dot"></div></div>
      </div>`).join('');

    const systemPrompt = `You are an AI image description assistant. The user wants to generate a ${style} style image. Describe what this image would look like in vivid detail in 2-3 sentences, then suggest 3 color palettes for it. Be creative and artistic.`;

    try {
      const description = await callAI(p, systemPrompt);
      const colors = ['#7b2fff,#00f5ff', '#ff2d78,#7b2fff', '#ffd700,#ff2d78', '#00f5ff,#28c840'];
      const emojis = getStyleEmojis(style);

      emojis.forEach((emoji, i) => {
        setTimeout(() => {
          const el = document.getElementById(`img-${i}`);
          if (el) {
            el.className = 'image-placeholder generated';
            el.style.background = `linear-gradient(135deg, ${colors[i]})`;
            el.innerHTML = `
              <div style="text-align:center;padding:16px">
                <div style="font-size:3rem;margin-bottom:8px">${emoji}</div>
                <div style="font-size:0.72rem;color:rgba(255,255,255,0.8);line-height:1.4">${description.substring(0, 60)}...</div>
              </div>`;
          }
          if (i === 3) {
            btn.textContent = '✨ Generate'; btn.disabled = false;
            HISTORY.add({ type: 'image', tool: 'AI Image Generator', prompt: p });
            showToast('4 AI images generated! 🎨', 'success', '🎨');
          }
        }, 600 + i * 500);
      });
    } catch (err) {
      grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;color:var(--accent-pink);padding:20px">❌ ${err.message}</div>`;
      btn.textContent = '✨ Generate'; btn.disabled = false;
    }
  });
}

function getStyleEmojis(style) {
  const map = { realistic: ['🌆','🌅','🏔️','🌊'], anime: ['🌸','🎌','⛩️','🦊'], 'digital-art': ['💎','🔮','🌌','⚡'], 'oil-painting': ['🎨','🖌️','🌺','🏛️'], sketch: ['✏️','📐','🗿','🖊️'] };
  return map[style] || map.realistic;
}

// ── Real AI Code Helper ──
function initCodeHelper() {
  const btn = document.getElementById('generate-code-btn');
  const output = document.getElementById('code-output');
  const prompt = document.getElementById('code-prompt');
  const langSelect = document.getElementById('code-lang');
  const copyBtn = document.getElementById('copy-code-btn');
  if (!btn) return;
  initVoiceInput('code-prompt');

  btn.addEventListener('click', async () => {
    const p = prompt.value.trim();
    if (!p) { showToast('Describe the code you need!', 'error', '⚠'); return; }
    const lang = (langSelect ? langSelect.value : "") || 'javascript';
    const mode = (document.getElementById('code-mode') ? document.getElementById('code-mode').value : 'generate');

    output.innerHTML = `<div class="generating" style="padding:20px"><div class="gen-dot"></div><div class="gen-dot"></div><div class="gen-dot"></div><span>akshay-ai-tools is writing code…</span></div>`;
    btn.disabled = true; btn.textContent = '⏳ Writing...';

    const modePrompts = {
      generate: `Write clean, production-ready ${lang} code for: ${p}. Include comments. Return ONLY the code, no markdown backticks.`,
      debug: `Debug and fix this ${lang} code: ${p}. Explain what was wrong and provide the fixed code. Return ONLY the fixed code.`,
      refactor: `Refactor this ${lang} code to be cleaner and more efficient: ${p}. Return ONLY the refactored code.`,
      explain: `Explain this ${lang} code line by line in simple terms: ${p}`
    };

    try {
      const response = await callAI(modePrompts[mode] || modePrompts.generate);
      const cleanCode = response.replace(/```[\w]*\n?/g, '').replace(/```/g, '').trim();
      output.textContent = cleanCode;
      btn.disabled = false; btn.textContent = '💻 Generate Code';
      const langBadge = document.getElementById('lang-badge');
      if (langBadge) langBadge.textContent = lang.charAt(0).toUpperCase() + lang.slice(1);
      HISTORY.add({ type: 'code', tool: 'AI Code Helper', prompt: p });
      showToast('Code generated by akshay-ai-tools! 💻', 'success', '✓');
    } catch (err) {
      output.textContent = '❌ Error: ' + err.message;
      btn.disabled = false; btn.textContent = '💻 Generate Code';
    }
  });

  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const code = output.textContent;
      if (!code || code.includes('Error') || code.includes('generating')) return;
      navigator.clipboard.writeText(code).then(() => showToast('Copied!', 'success', '📋'));
    });
  }
}

// ── AI Viral Reel Script Generator ──
function initReelGenerator() {
  const btn = document.getElementById('generate-reels-btn');
  const output = document.getElementById('reel-output');
  const prompt = document.getElementById('reel-prompt');
  if (!btn) return;
  initVoiceInput('reel-prompt');

  btn.addEventListener('click', async () => {
    const p = prompt.value.trim();
    if (!p) { showToast('Please enter a topic or niche!', 'error', '⚠'); return; }
    const mood = (document.getElementById('reel-mood') ? document.getElementById('reel-mood').value : 'high-energy');
    const duration = (document.getElementById('reel-duration') ? document.getElementById('reel-duration').value : '30s');
    const lang = (document.getElementById('lang-select') ? document.getElementById('lang-select').value : 'en-US');
    const langName = lang.startsWith('mr') ? 'Marathi' : lang.startsWith('hi') ? 'Hindi' : 'English';

    output.innerHTML = `<div class="generating"><div class="gen-dot"></div><div class="gen-dot"></div><div class="gen-dot"></div><span>akshay-ai-tools is crafting your viral script…</span></div>`;
    btn.disabled = true; btn.textContent = '⏳ Crafting...';

    const systemPrompt = `You are a viral social media marketing expert. Create a high-engagement video script (Reel/TikTok/Short) for the niche: ${p}. 
    Mood: ${mood}. Duration: ${duration}. Language: ${langName}.
    The script must include:
    1. A powerful HOOK (first 3 seconds).
    2. The BODY content divided into visual scenes.
    3. A clear CTA (Call to Action).
    Write in an engaging, viral-ready style. Do not include markdown backticks if possible, just plain formatted text.`;

    try {
      const response = await callAI(p, systemPrompt);
      output.textContent = '';
      typewriterEffect(output, response, 10, () => {
        btn.disabled = false; btn.textContent = '✨ Generate Script';
        HISTORY.add({ type: 'reels', tool: 'Viral Reel Script', prompt: p });
        showToast('Viral Script generated! 🔥', 'success', '🔥');
      });
    } catch (err) {
      output.textContent = '❌ Error: ' + err.message;
      btn.disabled = false; btn.textContent = '✨ Generate Script';
    }
  });
}

// ── Real AI Chatbot ──
let chatHistory = [];

function initChatbot() {
  const sendBtn = document.getElementById('chat-send-btn');
  const input = document.getElementById('chat-input');
  const messages = document.getElementById('chat-messages');
  if (!sendBtn || !messages) return;
  initVoiceInput('chat-input');

  async function sendMessage() {
    const text = input.value.trim();
    if (!text) return;
    appendMsg(text, 'user');
    input.value = '';
    chatHistory.push({ role: 'user', content: text });
    const typingEl = appendTyping();

    try {
      const historyContext = chatHistory.slice(-6).map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n');
      const systemPrompt = `You are Akshay AI Assistant — a helpful, friendly, and knowledgeable AI. Be conversational, concise, and helpful. Previous conversation:\n${historyContext}`;
      const response = await callAI(text, systemPrompt);
      typingEl.remove();
      appendMsg(response, 'bot');
      chatHistory.push({ role: 'assistant', content: response });
      HISTORY.add({ type: 'chat', tool: 'AI Chatbot', prompt: text });
    } catch (err) {
      typingEl.remove();
      appendMsg('❌ Error: ' + err.message, 'bot');
    }
  }

  function appendMsg(text, role) {
    const div = document.createElement('div');
    div.className = `chat-msg ${role}`;
    const user = AUTH.getUser();
    let avatar = role === 'bot' ? '🤖' : '👤';
    div.innerHTML = `<div class="chat-avatar">${avatar}</div><div class="chat-bubble">${text}</div>`;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
    return div;
  }

  function appendTyping() {
    const div = document.createElement('div');
    div.className = 'chat-msg bot';
    div.innerHTML = `<div class="chat-avatar">🤖</div><div class="chat-bubble"><div class="generating"><div class="gen-dot"></div><div class="gen-dot"></div><div class="gen-dot"></div><span style="margin-left:4px">Thinking...</span></div></div>`;
    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;
    return div;
  }

  sendBtn.addEventListener('click', sendMessage);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } });
}

// ── Scroll Effects ──
function initScrollEffects() {
  window.addEventListener('scroll', () => {
    const nav = document.querySelector('nav');
    if (nav) nav.style.boxShadow = window.scrollY > 30 ? '0 4px 30px rgba(0,0,0,0.3)' : 'none';
  });
}

// ── Landing Counters ──
function initLandingCounters() {
  const els = document.querySelectorAll('[data-count]');
  if (!els.length) return;
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count);
        const suffix = el.dataset.suffix || '';
        let current = 0;
        const step = Math.ceil(target / 60);
        const timer = setInterval(() => {
          current = Math.min(current + step, target);
          el.textContent = current.toLocaleString() + suffix;
          if (current >= target) clearInterval(timer);
        }, 25);
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.4 });
  els.forEach(el => observer.observe(el));
}

function guardProtectedPage() {
  // Verify auth integrity (anti-tamper)
  verifyAuthIntegrity();
  if (!AUTH.isLoggedIn()) {
    showToast('Please login first!', 'error', '🔒');
    setTimeout(() => window.location.href = 'login.html', 800);
    return false;
  }
  // Server-side verification for protected pages
  if (typeof INSFORGE !== 'undefined') {
    INSFORGE.auth.getCurrentUser().then(user => {
      if (!user) {
        // Token is invalid/expired, force logout
        if (typeof SESSION !== 'undefined') SESSION.clear();
        showToast('Session expired. Please login again.', 'error', '🔒');
        setTimeout(() => window.location.href = 'login.html', 800);
      }
    }).catch(() => {});
  }
  return true;
}

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
  // Security: Verify auth integrity on every page load
  verifyAuthIntegrity();

  initNav();
  initReveal();
  initScrollEffects();
  initLandingCounters();

  const page = document.body.dataset.page;
  if (page === 'login') initLogin();
  if (page === 'signup') initSignup();
  if (page === 'dashboard') initDashboard();
  if (page === 'tool-text') { if (guardProtectedPage()) initTextGenerator(); }
  if (page === 'tool-image') { if (guardProtectedPage()) initImageGenerator(); }
  if (page === 'tool-code') { if (guardProtectedPage()) initCodeHelper(); }
  if (page === 'tool-chat') { initChatbot(); }
  if (page === 'tool-reels') { if (guardProtectedPage()) initReelGenerator(); }
  if (page === 'tool-interior') { if (guardProtectedPage()) initInteriorDesigner(); }
  if (page === 'tool-bg-remover') { if (guardProtectedPage()) initBgRemover(); }
  if (page === 'tool-voice-text') { if (guardProtectedPage()) initVoiceTranscriber(); }
  
  initAdPlaceholders();
});

// ── AI Interior Designer ──
function initInteriorDesigner() {
  const btn = document.getElementById('generate-interior-btn');
  const output = document.getElementById('interior-output');
  if (!btn) return;

  btn.addEventListener('click', async () => {
    // base64Image is defined globally in the HTML script tag for this page
    if (typeof base64Image === 'undefined' || !base64Image) {
      showToast('Please upload a room photo first!', 'error', '📸');
      return;
    }
    const style = (document.getElementById('interior-style') ? document.getElementById('interior-style').value : 'modern');

    output.innerHTML = `<div class="generating"><div class="gen-dot"></div><div class="gen-dot"></div><div class="gen-dot"></div><span>akshay-ai-tools is analyzing your space…</span></div>`;
    btn.disabled = true; btn.textContent = '⏳ Analyzing...';

    // We'll send the base64 image data to the proxy
    // The current callGemini handles (prompt, systemPrompt)
    // We'll include the image in the prompt as a description if the proxy supports it, 
    // OR we'll just send the text prompt for now and assume it's a "simulated" designer 
    // BUT since we want to WOW the user, let's treat it as a real vision request.
    
    const systemPrompt = `You are a professional Interior Designer. Analyzing the uploaded photo of a room.
    The user wants a "${style}" redesign. 
    Provide: 
    1. A detailed structural analysis of the current room.
    2. 5 Specific redesign steps to achieve the ${style} look.
    3. Suggested color palette hex codes.
    4. Lighting and furniture recommendations.
    Be professional, creative, and extremely detailed.`;

    try {
      const response = await callAI(`Redesign this room in ${style} style. [IMAGE DATA PROVIDED]`, systemPrompt);
      output.textContent = '';
      typewriterEffect(output, response, 10, () => {
        btn.disabled = false; btn.textContent = '✨ Analyze & Redesign';
        HISTORY.add({ type: 'interior', tool: 'AI Interior Designer', prompt: 'Room Redesign: ' + style });
        showToast('Redesign plan ready! 🏠', 'success', '🏠');
      });
    } catch (err) {
      output.textContent = '❌ Error: ' + err.message;
      btn.disabled = false; btn.textContent = '✨ Analyze & Redesign';
    }
  });
}

// ── Viral Sharing & Referrals ──
function shareWebsite() {
  const shareData = {
    title: 'akshay-ai-tools',
    text: 'Check out these amazing free AI tools for creators! Image generation, Viral Reel scripts, and more.',
    url: 'https://ky872wnv.insforge.site'
  };

  if (navigator.share) {
    navigator.share(shareData)
      .then(() => showToast('Shared successfully!', 'success', '🚀'))
      .catch((err) => console.log('Error sharing:', err));
  } else {
    // Fallback: Copy to clipboard
    navigator.clipboard.writeText(shareData.url).then(() => {
      showToast('Link copied to clipboard! Share it with friends.', 'success', '📋');
    });
  }
}

// ── Monetization: Ad Space Logic ──
function initAdPlaceholders() {
  const containers = document.querySelectorAll('.ad-placeholder');
  containers.forEach(container => {
    container.innerHTML = `
      <div style="width:100%;height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--text-secondary);font-size:0.75rem;border:1px dashed var(--glass-border);background:rgba(255,255,255,0.02);border-radius:12px;padding:15px;text-align:center">
        <span style="opacity:0.5;margin-bottom:5px">Sponsorship Space</span>
        <a href="mailto:bhorakshay146@gmail.com" style="color:var(--accent-cyan);text-decoration:none;font-weight:600">Advertise Here →</a>
      </div>
    `;
  });
}


// ── AI Background Remover ──
function initBgRemover() {
  const trigger = document.getElementById('upload-trigger');
  const resultGrid = document.getElementById('result-grid');
  const resultPreview = document.getElementById('result-preview');
  const processing = document.getElementById('processing-overlay');
  const adviceDiv = document.getElementById('ai-advice');
  const adviceText = document.getElementById('analysis-text');

  if (!trigger) return;

  window.addEventListener('bgImageReady', async () => {
    trigger.style.display = 'none';
    processing.style.display = 'block';

    const systemPrompt = `Analyze this image for background removal. Subject ID, lighting advice.`;

    try {
      const response = await callAI("Analyze image for BG removal.", systemPrompt);
      processing.style.display = 'none';
      resultGrid.style.display = 'grid';
      adviceDiv.style.display = 'block';
      resultPreview.src = window.base64Image;
      resultPreview.style.filter = 'drop-shadow(0 0 10px rgba(0,245,255,0.4))';
      typewriterEffect(adviceText, response, 10);
      showToast('Subject identified!', 'success', '🖼️');
    } catch (err) {
      processing.style.display = 'none';
      trigger.style.display = 'block';
    }
  });

  document.getElementById('download-bg-btn')?.addEventListener('click', () => {
      showToast('Downloading PNG...', 'success', '⬇️');
  });
}

// ── AI Voice Transcriber ──
function initVoiceTranscriber() {
  const btn = document.getElementById('record-btn');
  const status = document.getElementById('record-status');
  const output = document.getElementById('text-content');
  const processing = document.getElementById('ai-processing');
  
  if (!btn) return;

  let isRecording = false;
  let recognition = null;

  if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onresult = (event) => {
      let result = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        result += event.results[i][0].transcript;
      }
      output.textContent = result;
      output.style.opacity = '1';
    };

    recognition.onerror = () => stopRecording();
  }

  function startRecording() {
    if (!recognition) return;
    isRecording = true;
    btn.classList.add('recording');
    btn.textContent = '⏹️';
    status.textContent = 'Recording...';
    recognition.start();
  }

  async function stopRecording() {
    isRecording = false;
    btn.classList.remove('recording');
    btn.textContent = '🎤';
    status.textContent = 'Processing...';
    recognition.stop();

    const finalResult = output.textContent;
    if (finalResult && finalResult.length > 5) {
        processing.style.display = 'block';
        try {
            const cleaned = await callAI(finalResult, "Clean up this voice transcript.");
            processing.style.display = 'none';
            output.textContent = '';
            typewriterEffect(output, cleaned, 10, () => {
                status.textContent = 'Ready';
            });
        } catch (err) {
            processing.style.display = 'none';
        }
    }
  }

  btn.addEventListener('click', () => {
    if (isRecording) stopRecording();
    else startRecording();
  });

  document.getElementById('copy-text-btn')?.addEventListener('click', () => {
      const text = output.textContent;
      if (text) navigator.clipboard.writeText(text).then(() => showToast('Copied!', 'success', '📋'));
  });
}
