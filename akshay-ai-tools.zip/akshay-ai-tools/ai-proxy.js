// Insforge Edge Function: AI API Proxy (OpenRouter)
// Securely proxies AI API calls so your keys are never exposed on the website.
// + Rate limiting, input validation, and security hardening

// ── CONFIGURATION ──
const OPENROUTER_API_KEY = "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"; 
const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";

// ── Server-side Rate Limiter (per IP) ──
const rateLimitMap = new Map();
const RATE_LIMIT_MAX = 15;       // max requests per window
const RATE_LIMIT_WINDOW = 60000; // 1 minute

function checkRateLimit(ip) {
  const now = Date.now();
  const key = ip || 'unknown';
  
  if (!rateLimitMap.has(key)) {
    rateLimitMap.set(key, [now]);
    return true;
  }
  
  const timestamps = rateLimitMap.get(key).filter(t => now - t < RATE_LIMIT_WINDOW);
  
  if (timestamps.length >= RATE_LIMIT_MAX) {
    rateLimitMap.set(key, timestamps);
    return false;
  }
  
  timestamps.push(now);
  rateLimitMap.set(key, timestamps);
  return true;
}

// ── Input Sanitizer ──
function sanitizeInput(str, maxLen = 3000) {
  if (!str || typeof str !== 'string') return '';
  return str.trim().substring(0, maxLen);
}

module.exports = async function (request) {
  const commonHeaders = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    // Security headers
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
  };

  // Handle CORS preflight
  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: commonHeaders });
  }

  if (request.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: commonHeaders });
  }

  try {
    // Rate limit check
    const clientIP = request.headers.get('x-forwarded-for') || request.headers.get('cf-connecting-ip') || 'unknown';
    if (!checkRateLimit(clientIP)) {
      return new Response(JSON.stringify({ 
        error: 'Too many requests. Please wait a moment and try again.' 
      }), { status: 429, headers: commonHeaders });
    }

    const body = await request.json();
    const { prompt, systemPrompt, temperature, maxTokens, model } = body;

    // Validate and sanitize prompt
    const cleanPrompt = sanitizeInput(prompt, 3000);
    if (!cleanPrompt) {
      return new Response(JSON.stringify({ error: 'Prompt is required' }), { status: 400, headers: commonHeaders });
    }

    const cleanSystemPrompt = sanitizeInput(systemPrompt, 2000);

    // ── OPENROUTER LOGIC ──
    const messages = cleanSystemPrompt 
      ? [{ role: "system", content: cleanSystemPrompt }, { role: "user", content: cleanPrompt }]
      : [{ role: "user", content: cleanPrompt }];
    
    const response = await fetch(OPENROUTER_URL, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
        'HTTP-Referer': 'https://ky872wnv.insforge.site',
        'X-Title': 'Akshay AI Tools'
      },
      body: JSON.stringify({
        model: model || "google/gemini-2.0-flash-001",
        messages: messages,
        temperature: Math.min(Math.max(temperature || 0.7, 0), 2), // clamp 0-2
        max_tokens: Math.min(maxTokens || 2048, 4096) // cap at 4096
      })
    });

    const data = await response.json().catch(() => ({ error: { message: "Failed to parse OpenRouter response as JSON" } }));
    
    if (!response.ok) {
      return new Response(JSON.stringify({ 
        error: data.error?.message || 'AI service temporarily unavailable'
      }), { status: response.status, headers: commonHeaders });
    }

    const text = data.choices?.[0]?.message?.content || 'No response received. Please check your prompt or try again.';
    return new Response(JSON.stringify({ text }), { status: 200, headers: commonHeaders });

  } catch (e) {
    const errorMsg = e instanceof Error ? e.message : String(e);
    return new Response(JSON.stringify({ error: "Service temporarily unavailable. Please try again." }), { status: 500, headers: commonHeaders });
  }
};
